import { Component, OnInit } from '@angular/core';
import datas from './LoginCredentials/details.json';
import { ReplaySubject } from 'rxjs';
import { NgForOf } from '@angular/common';
import {HttpClient} from '@angular/common/http'
import { Router } from '@angular/router';
@Component({
  selector: 'app-logincheck',
  templateUrl: './logincheck.component.html',
  styleUrls: ['./logincheck.component.css']
})
export class LogincheckComponent implements OnInit {
logins=[
  {
    "username":"mudit",
    "password":"1234"
  }
];

  constructor(private router:Router) { }

  ngOnInit() {
  }
  checklog(form)
 {
  for(let data of datas)
  {
    if(form.username== data.username && form.password==data.password)
    {
      alert("successfully")
      this.router.navigate(['/loginsuccess'])
    }
    else
    {
    alert("failed")
    return
    }
  }
}
}
