import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PractiseComponent } from './practise/practise.component';
import { FormsModule }   from '@angular/forms';
import { SortComponent } from './sort/sort.component';
import { SearchComponent } from './search/search.component';
import { FilterPipe } from './filter.pipe';
import { Practice1Component } from './practice1/practice1.component';

@NgModule({
  declarations: [
    AppComponent,
    PractiseComponent,
    SortComponent,
    SearchComponent,
    FilterPipe,
    Practice1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
