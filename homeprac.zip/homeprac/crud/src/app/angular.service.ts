import { Injectable } from '@angular/core';
import data from './search/File/booklist.json'
@Injectable({
  providedIn: 'root'
})
export default class  {
  books = data
  constructor() { }
  display() {
    return this.books
  }
}
