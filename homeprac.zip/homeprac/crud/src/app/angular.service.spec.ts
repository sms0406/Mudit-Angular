import { TestBed } from '@angular/core/testing';

describe('AngularService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));
});
