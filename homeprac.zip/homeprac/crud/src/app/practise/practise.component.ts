import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-practise',
  templateUrl: './practise.component.html',
  styleUrls: ['./practise.component.css']
})
export class PractiseComponent implements OnInit {
  index
  employees =
    [
      { empId: 1001, empName: "Rahul", empSal: 9000, empDep: "Java" },
      { empId: 1002, empName: "Sachin", empSal: 19000, empDep: "OraApps" },
      { empId: 1003, empName: "Vikash", empSal: 29000, empDep: "BI" },
    ];
  constructor() { }

  ngOnInit() {
  }
  addMethod(form) {
    this.employees.push(form)
  }
  delete(i) {
    this.employees.splice(i, 1)
  }
  getIndex(i) {
    this.index = i
  }
  updateMethod(form) {

    if (form.empId != null) {
      this.employees[this.index].empId = form.empId;
    }
    if (form.empName != null) {


      this.employees[this.index].empName = form.empName;
    }
    if (form.empSal != null) {

      this.employees[this.index].empSal = form.empDep;
    }
    if (form.empDep != null) {
      this.employees[this.index].empDep = form.empDep;
    }

  }

}
