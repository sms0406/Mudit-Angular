import { Component, OnInit } from '@angular/core';
import AngularService  from "../angular.service"
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  books
  search
  constructor(private service: AngularService) { }

  ngOnInit() {
    this.books=this.service.display()
    console.log(this.books)
  }
  setTypeId(value)
  {
    this.search={id: value}
  }
  setTypeTitle(value)
  {
    this.search={title: value} 
  }
  setTypeAuthor(value)
  {
    this.search={author: value} 
  }
  setTypeYear(value)
  {
    this.search={year: value} 
  }
}
  

