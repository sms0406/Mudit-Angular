import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab2',
  templateUrl: './lab2.component.html',
  styleUrls: ['./lab2.component.css']
})
export class Lab2Component implements OnInit {
  employees=[
    {empId:1001,empName:"Rahul",empSal:9000,empDep:"Java"},
    {empId:1002,empName:"Sachin",empSal:19000,empDep:"OraApps"},
    {empId:1003,empName:"Vikash",empSal:29000,empDep:"BI"},
    ];
  index
  constructor() { }

  ngOnInit() {
  }
  addMethod(form)
  {
    this.employees.push(form)
  }
  deleteMethod(i){
    this.employees.splice(i,1)
  }
  updateIndex(i)
  {
    this.index=i
  }
  updateMethod(form)
  {
    
    if(form.empId!=null)
      this.employees[this.index].empId=form.empId;
    if(form.empName!=null)
      this.employees[this.index].empName=form.empName;
    if(form.empSal!=null)
      this.employees[this.index].empSal=form.empSal;
    if(form.empDep!=null)
      this.employees[this.index].empDep=form.empDep;
  }
}
